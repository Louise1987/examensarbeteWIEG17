﻿define("epi-ecf-ui/widget/_ContentSecurableList", [
// dojo
    "dojo/_base/array",
    "dojo/_base/declare",
    "dojo/_base/lang",

    "dojo/aspect",
    "dojo/dom-class",
// epi
    "epi-cms/contentediting/ContentActionSupport",
    "epi-cms/widget/_ConfigurableContentListBase",
// resources
    "epi/i18n!epi/cms/nls/commerce.widget.catalogcontentlist"
], function (
// dojo
    array,
    declare,
    lang,

    aspect,
    domClass,
// epi
    ContentActionSupport,
    _ConfigurableContentListBase,
// resources
    catalogContentListResources) {

    return declare([_ConfigurableContentListBase], {
        // summary:
        //      Lists the content of catalogs and categories with access right column.
        // tags:
        //      protected

        getColumnSettings: function () {
            // summary:
            //      Returns an object with the settings for the columns of the grid.
            // tags:
            //      protected extensions

            return {
                accessRight: {
                    className: "epi-columnVeryNarrow",
                    renderHeaderCell: function () { },
                    renderCell: this._renderAccessRightInfo.bind(this)
                }
            };
        },

        setupEvents: function () {
            // summary:
            //      Initialization events on list.
            // tags:
            //      protected extensions

            this.inherited(arguments);

            this.own(aspect.around(this.grid, "insertRow", this._aroundInsertRow.bind(this)));
        },

        _aroundInsertRow: function (original) {
            // summary:
            //      Called 'around' the insertRow method to add more class for current row.
            // tags:
            //      private

            return function (object, parent, beforeNode, i, options) {
                // Call original method
                var row = original.apply(this.grid, arguments);
                domClass.toggle(row, "epi-secondaryText", object && this._isReadOnlyAccess(object.accessMask));

                return row;
            }.bind(this);
        },

        _renderAccessRightInfo: function (item, value, node, options) {
            // summary:
            //      Shows access right information for the current catalog content.
            // tags:
            //      private

            var accessRightInfo = { icon: "", title: "" };
            if (this._isReadOnlyAccess(item.accessMask)) {
                accessRightInfo.icon = "epi-iconLock";
                accessRightInfo.title = catalogContentListResources.tooltip.contentlocked;
            }

            node.innerHTML = lang.replace("<span class='dijitInline dijitReset dijitIcon {icon}' title='{title}' role='presentation'>&nbsp;</span>", accessRightInfo);
        },

        _isReadOnlyAccess: function (accessMask) {
            // summary:
            //      Verifies current access mask is read-only or not.
            // tags:
            //      private

            return accessMask <= ContentActionSupport.accessLevel.Read;
        }
    });
});