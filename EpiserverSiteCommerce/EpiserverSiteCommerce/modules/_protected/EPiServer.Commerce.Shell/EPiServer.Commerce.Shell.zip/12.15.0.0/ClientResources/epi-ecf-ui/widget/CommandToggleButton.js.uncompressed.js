define("epi-ecf-ui/widget/CommandToggleButton", [
    "dojo/_base/declare",
    "dijit/form/ToggleButton",
    "epi/shell/command/_CommandModelBindingMixin"
], function (declare, ToggleButton, _CommandModelBindingMixin) {
    return declare([ToggleButton, _CommandModelBindingMixin]);
});