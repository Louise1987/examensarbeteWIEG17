require({cache:{
'url:epi-ecf-ui/widget/templates/_DiscountTreeNode.html':"﻿<div class=\"dijitTreeNode epi-categoryTreeNode\" role=\"presentation\">\r\n    <a href=\"#\" tabIndex=\"-1\" data-dojo-attach-point=\"rowNode\" class=\"dijitTreeRow\" role=\"presentation\">\r\n        <div data-dojo-attach-point=\"indentNode\" class=\"dijitInline\"></div>\r\n        <span data-dojo-attach-point=\"contentNode\" class=\"dijitTreeContent\" role=\"presentation\">\r\n            <span data-dojo-attach-point=\"expandoNode\" class=\"dijitTreeExpando\" role=\"presentation\"></span>\r\n            <span class=\"epi-checkboxNode dijitTreeExpando\">\r\n                <div data-dojo-attach-point=\"checkbox\" data-dojo-type=\"dijit/form/CheckBox\"\r\n                     data-dojo-attach-event=\"onClick: onNodeClicked\" tabIndex=\"-1\"></div>\r\n            </span>\r\n            <span data-dojo-attach-point=\"expandoNodeText\" class=\"dijitExpandoText\" role=\"presentation\"></span>\r\n            <span data-dojo-attach-point=\"iconNode\" class=\"dijitIcon dijitTreeIcon dijitHidden\" role=\"presentation\"></span>\r\n            <span data-dojo-attach-point=\"labelNode\" class=\"dijitTreeLabel dojoxEllipsis\" role=\"treeitem\"\r\n                  tabindex=\"-1\" aria-selected=\"false\" data-dojo-attach-event=\"onclick:_onLabelClick, keyup:_onLabelKeyUp\">\r\n            </span>\r\n        </span>\r\n    </a>\r\n    <div data-dojo-attach-point=\"containerNode\" class=\"dijitTreeContainer\" role=\"presentation\" style=\"display: none;\"></div>\r\n</div>"}});
﻿define("epi-ecf-ui/widget/_DiscountTreeNode", [
// dojo
    "dojo/_base/array",
    "dojo/_base/declare",
    "dojo/_base/lang",
    "dojo/dom-class",
    "dojo/dom-style",
    "dojo/keys",
// dijit
    "dijit/Tree",
    "dijit/_TemplatedMixin",
    "dijit/form/CheckBox",
    "dijit/_WidgetsInTemplateMixin",
// resources
    "dojo/text!./templates/_DiscountTreeNode.html"
],

function (
// dojo
    array,
    declare,
    lang,
    domClass,
    domStyle,
    keys,
// dijit
    Tree,
    _TemplatedMixin,
    CheckBox,
    _WidgetsInTemplateMixin,
// resources
    template
) {

    return declare([Tree._TreeNode, _TemplatedMixin, _WidgetsInTemplateMixin], {
        // summary:
        //      A customized tree node for displaying a node with a checkbox.
        // tags:
        //      internal

        templateString: template,

        postCreate: function () {
            // summary:
            //      Place checkbox into the tree node after node created.
            // tags:
            //      protected

            this.inherited(arguments);

            if (this.item) {
                this.checkbox.value = this.item.id;
            }
        },

        onNodeSelectChanged: function () {
            // summary:
            //      on node selection changed.
            // tags:
            //      public
        },

        _setItemAttr: function (item) {
            // summary:
            //      set attributes/class for item node.
            // tags:
            //      private

            this._set("item", item);

            var hidden = !item || item.hidden === true;
            var disabled = !item || item.disabled === true;
            var checked = !disabled && item && item.selected === true;

            this.checkbox.set("disabled", disabled);
            this.set("checked", checked);

            domClass.toggle(this.labelNode, "is-disabled", disabled);
            domStyle.set(this.rowNode, "display", hidden ? "none" : "");
        },

        onNodeClicked: function () {
            // summary:
            //      on node clicked event.
            // tags:
            //      protected

            var checked = this.checkbox.get("checked");
            this.set("checked", checked);

            if (!checked) {
                this._updateParentNode();
            }
            this._updateChildrenNode(checked);

            this.onNodeSelectChanged();
        },

        _isCheckboxEnabled: function () {
            return this.checkbox && !this.checkbox.get("disabled");
        },

        _updateParentNode: function () {
            // summary:
            //      Update parent node.
            // tags:
            //      private

            var parentNode = this.getParent();
            if (parentNode && parentNode.get("checked")) {
                parentNode.set("checked", false);
                parentNode._updateParentNode();
            }
        },

        _updateChildrenNode: function (checked) {
            // summary:
            //      Update children nodes.
            // checked:
            //      Indicated that the node is checked.
            // tags:
            //      private
            if (this.item && this.item.hasChildren) {
                array.forEach(this.getChildren(), function (childNode) {
                    if (childNode._isCheckboxEnabled() && childNode.get("checked") !== checked) {
                        childNode.set("checked", checked);
                        childNode._updateChildrenNode(checked);
                    }
                });
            }
        },

        _onLabelClick: function () {
            // summary:
            //      clicking the label toggles the checkbox
            // tags:
            //      private

            if (!this._isCheckboxEnabled()) {
                return;
            }
            this.set("checked", !this.checkbox.checked);
            this.onNodeClicked();
        },

        _onLabelKeyUp: function (evt) {
            // summary:
            //      pressing a key on the label toggles the checkbox
            // tags:
            //      private

            if (evt.keyCode === keys.SPACE || evt.keyCode === keys.ENTER) {
                this._onLabelClick();
            }
        },

        _getCheckedAttr: function () {
            // summary:
            //      Get checked status of the node.
            // tags:
            //      private

            return this.checkbox && this.checkbox.get("checked");
        },

        _setCheckedAttr: function (checked) {
            // summary:
            //      Check/UnCheck the node.
            // tags:
            //      private

            if (!this._isCheckboxEnabled()) {
                this.checkbox.set("checked", false);
                return;
            }
            this.checkbox.set("checked", checked);
        }
    });

});